from functools import wraps
from flask import Flask, request, render_template, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin,BaseView,AdminIndexView,expose
from flask_admin.contrib.sqla import ModelView
from flask_babelex import Babel
from sqlalchemy import and_, or_

app = Flask(__name__)

############################################
# 数据库
############################################
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:123456@localhost:3306/test_1'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.secret_key = '\xc9ixnRb\xe40\xd4\xa5\x7f\x03\xd0y6\x01\x1f\x96\xeao+\x8a\x9f\xe4'
db = SQLAlchemy(app)
 
############################################
# 辅助函数、装饰器
############################################
# 登录检验（用户名、密码验证）
def valid_login(username, password):
    user = User.query.filter(and_(User.username == username, User.password == password)).first()
    if user:
        return True
    else:
        return False


# 注册检验（用户名、邮箱验证）
def valid_regist(username, email):
    user = User.query.filter(or_(User.username == username, User.email == email)).first()
    if user:
        return False
    else:
        return True

# 登录
def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # if g.user:
        if session.get('username'):
            return func(*args, **kwargs)
        else:
            return redirect(url_for('login', next=request.url)) # 
    return wrapper


############################################
# 路由
############################################

# 自动跳转登录页
@app.route('/')
def home():
    username = session.get('username')
    if username != None:
        return render_template('index.html', username=session.get('username'))
    else:
        return render_template('login.html')

#首页
@app.route('/index')
def index():
    username = session.get('username')
    welcome = Welcome.query.order_by(Welcome.join_time.desc()).all()
    if username != None:
        return render_template('index.html', username=session.get('username'),welcome=welcome)
    else:
        return render_template('login.html')

#编程列表
@app.route('/programmes')
@login_required
def programmes():
    page = request.args.get('page',1,type=int)
    username = session.get('username')
    paginate = Challenge.query.order_by('title').paginate(page, per_page=10, error_out=False)
    if username != None:
        return render_template('programme.html', username=session.get('username'),users=paginate.items,pagination=paginate)
    else:
        return render_template('login.html')

#跳转编程题目
@app.route('/programmes_/<string:title>', methods=['GET'])
def programmes_(title):
    username = session.get('username')
    post = Challenge.query.filter(Challenge.title == title).first()
    if username != None:
        return render_template('programmes_.html', username=session.get('username'),post=post)
    else:
        return render_template('login.html')

#选择题
@app.route('/subject')
@login_required
def subject():
    page = request.args.get('page',1,type=int)
    username = session.get('username')
    paginate = Choice.query.order_by('join_time').paginate(page=page, per_page=1, error_out=False)
    if username != None:
        return render_template('subject.html', username=session.get('username'),users=paginate.items,pagination=paginate)
    else:
        return render_template('login.html')

#做题情况
@app.route('/solve')
def solve():
    username = session.get('username')
    if username != None:
        return render_template('solve.html', username=session.get('username'))
    else:
        return render_template('login.html')

#登录
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if valid_login(request.form['username'], request.form['password']):
            flash("成功登录！")
            session['username'] = request.form.get('username')
            if session['username'] == 'admin':
                return redirect(url_for('admin.index'))
            else:
                return redirect(url_for('index'))
        else:
            error = '错误的用户名或密码！'

    return render_template('login.html', error=error)

#注销
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

#注册
@app.route('/regist', methods=['GET','POST'])
def regist():
    error = None
    if request.method == 'POST':
        if request.form['password1'] != request.form['password2']:
            error = '两次密码不相同！'
        elif valid_regist(request.form['username'], request.form['email']):
            user = User(username=request.form['username'], password=request.form['password1'], email=request.form['email'])
            db.session.add(user)
            db.session.commit()
            
            flash("成功注册！")
            return redirect(url_for('login'))
        else:
            error = '该用户名或邮箱已被注册！'
    
    return render_template('regist.html', error=error)

#个人中心
@app.route('/panel')
@login_required
def panel():
    username = session.get('username')
    user = User.query.filter(User.username == username).first()
    return render_template("panel.html", user=user)


############################################
# 后台管理
############################################
#flask_admin汉化
babel = Babel(app)
app.config['BABEL_DEFAULT_LOCALE'] = 'zh_CN'

# 定义ORM
#user数据库定义
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(80))
    email = db.Column(db.String(120), unique=True)

    def __repr__(self):
        return '<User %r>' % self.username

class Challenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), unique=True)
    t_type = db.Column(db.String(10))
    t_body = db.Column(db.String(10000), unique=True)

class Welcome(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    w_body = db.Column(db.String(1000))
    join_time = db.Column(db.String(100))

class Choice(db.Model):
    __tablename__ = 'c_choice'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(50), unique=True)
    type = db.Column(db.String(20))
    A = db.Column(db.String(50))
    B = db.Column(db.String(50))
    C = db.Column(db.String(50))
    D = db.Column(db.String(50))
    choice = db.Column(db.String(5))
    join_time = db.Column(db.String(50))


#主页修改为welcome
admin = Admin(
    app,
    name = '后台管理平台',
    index_view=AdminIndexView(
        name='首页',
        template='welcome.html',
        url='/admin'
    )
)

#flask 新增视图
admin.add_view(ModelView(Welcome,db.session, name='公告'))
admin.add_view(ModelView(User,db.session, name='用户管理'))
admin.add_view(ModelView(Challenge,db.session, name='编程题目'))
admin.add_view(ModelView(Choice,db.session, name='选择题目'))

#开始
if __name__ == '__main__':
    app.run(debug = True)